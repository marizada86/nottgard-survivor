# Durvall: pacote para o Caio (BUG-028, heróis "patinam" ao andar)

Gerado em 2026-10-08 a partir do projeto Nottgard Survivors. Todo o conteúdo é do próprio projeto; nada aqui foi alterado.

## O problema

Ao andar **de lado e nas diagonais** (leste, sudeste, nordeste e os espelhos), os heróis "patinam": o corpo desliza mais
rápido do que os pés desenhados parecem andar. Para cima e para baixo o dono considera que está bom. Vale para todos os
heróis; o Durvall é o piloto. Já foi tentado, sem sucesso, subir o fps da animação (15) e ligar a velocidade de animação à do
herói; foi revertido. As tentativas de gerar uma corrida lateral nova por imagem (v03 a v06) e um piloto articulado estão
descritas em `historico/` (EVID-169 a 175); nenhuma foi aprovada.

## Como o jogo usa a arte (contrato técnico do Durvall)

| Item | Valor |
|---|---|
| Célula de cada quadro | 256 × 384 px, PNG com transparência |
| Tiras | `idle` 4 quadros a 8 fps; `move_*` 6 quadros a 10 fps em loop; `attack` 4 a 12 fps; `active` 6 a 12 fps; `death` 6 a 9 fps |
| Tiras de andar **usadas em jogo** | `move_e`, `move_se`, `move_s`, `move_ne`, `move_n` |
| Direções por espelho (`flip_h`) | oeste = `move_e`, sudoeste = `move_se`, noroeste = `move_ne` |
| `move_w`, `move_sw`, `move_nw`, `move` | **não são carregadas pelo jogo** (arquivos antigos) |
| Escala na tela | 60 px de altura para 231 px de arte no idle, ou seja, **0,26** |
| Linha dos pés | y = 376 px na célula (os pés ficam ancorados aí, em cima da sombra) |
| Velocidade de andar | 190 px de tela por segundo (todas as direções) |
| Ciclo de andar | 6 quadros ÷ 10 fps = 0,6 s, ou seja, o herói percorre ~114 px de tela por ciclo |

Regras que os testes automáticos do projeto cobram de cada tira de andar: altura do corpo dentro de ±16% do idle; pés a ±6 px da
linha dos pés do idle; massa de pixels dentro de ±30% do idle; nenhum pixel visível encostado na borda da célula.

## O que a medição mostrou (`diagnostico/`)

- Em campo livre, com teclado, não há troca de tira nem queda ao idle: o código de direção está limpo.
- A abertura dos pés desenhada é pequena. Velocidade de chão que a planta do pé desenhada implicaria, no Durvall a 10 fps:
  E 61, SE 12, S 9, NE 17, N 27 px/s, contra 190 px/s reais. (Métrica estática e grosseira: serve para ordem de grandeza.)
- Isso vale também para N e S, onde o dono não percebe o problema; a diferença de percepção ainda não tem explicação.
- Falta a coleta no PC do dono (descompasso entre física e renderização).
- Os links relativos dos `.md` (imagens e guias em `.atena/generated/...`) apontam para arquivos que **não estão** neste pacote.

## O que pedimos ao Caio

1. Avaliar a causa: arte (passada curta), ritmo (fps), velocidade ou outra, e dizer o que mudaria.
2. Se for a arte, propor ou produzir tiras novas de `move_e`, `move_se` e `move_ne` (e `move_s` / `move_n`, se necessário)
   com passada compatível com 190 px/s (ou indicar quantos quadros e fps ele precisa, por exemplo 8 quadros).
   Mesmo formato do contrato acima, mesma origem e mesma linha dos pés, identidade preservada (rosto, cabelo prateado,
   armadura escura, tecido vinho, Espada Sombria na mão correta).
3. Se a solução exigir mudar o jogo (mais quadros, outro fps, outra velocidade), descrever o que mudar.

## Conteúdo do pacote

| Pasta | O quê |
|---|---|
| `assets/animations/` | 13 tiras PNG atuais do Durvall (idle, move, move_e/se/s/ne/n/nw/sw/w, attack, active, death) |
| `assets/heroes/`, `assets/portraits/` | sprite estático e retrato |
| `prompts/` | `ART-PROMPTS-002/015/016/055` e `CHATGPT-FILA-024` (todos multi-herói; procurar "Durvall"), guia de poses da corrida lateral, prompts e manifesto do pacote de animação do Durvall |
| `historico/` | SPEC-018 (direções de movimento) e EVID-169 a 175 (tentativas de corrida e piloto articulado) |
| `diagnostico/` | EVID-197 (diagnóstico do BUG-028) e `stride.csv` (medição de passada de todos os heróis) |
